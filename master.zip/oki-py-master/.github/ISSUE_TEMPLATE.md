In order to submit an issue, please ensure you can check the following. Thanks!

* [ ] Declare which version of Python you are using (`python --version`)
* [ ] Declare which operating system you are using
