# -*- coding: utf-8 -*-
from __future__ import division
from __future__ import print_function
from __future__ import absolute_import
from __future__ import unicode_literals


def what_we_want():
    '''Returns what we want for open data.'''
    return 'We want the data raw, and we want the data now.'
